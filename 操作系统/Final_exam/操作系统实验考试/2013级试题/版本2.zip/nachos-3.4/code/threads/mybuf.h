
int BufCreater(int bufsize, int totalproducers);

void BufProducer(int which);

void BufConsumer(int which);
